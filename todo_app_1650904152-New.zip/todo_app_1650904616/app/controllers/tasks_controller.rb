class TasksController < ApplicationController
  before_action :set_task, only: [:destroy, :complete, :edit, :update]
  before_action :set_category, only: [:index, :new, :create, :destroy, :complete]

  def index
    if @category
      @tasks = @category.tasks
      @task = @category.tasks.new
    else
      @incomplete_tasks = Task.incomplete
      @tasks = Task.incomplete
      @complete_tasks = Task.complete
      @categories = Category.all
    end
  end

  def create
    if @category
      @task = @category.tasks.new(task_params)
      @task.status = :incomplete
      if @task.save
        redirect_to category_tasks_path(@category), notice: 'Task was successfully created.'
      else
        render :new
      end
    else
      redirect_to categories_path, alert: 'Category not found.'
    end
  end  

  def edit
  end

  def update
    if @task.update(task_params)
      redirect_to category_tasks_path(@category), notice: 'Task was successfully updated.'
    else
      render :edit
    end
  end  

  def destroy
    @task.destroy
    redirect_to category_tasks_path(@category), notice: 'Task was successfully deleted.'
  end

  def complete
    @task.complete!
    redirect_to category_tasks_path(@category), notice: 'Task was successfully marked as complete.'
  end  

  private

  def set_task
    @task = Task.find(params[:id])
  end

  def set_category
    @category = Category.find_by(id: params[:category_id]) # แก้เป็น find_by เพื่อหลีกเลี่ยงข้อผิดพลาดหาก category ไม่พบ
  end

  def task_params
    params.require(:task).permit(:title, :description, :category_id)
  end
end
